part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const LOGIN_SCREEN = _Paths.LOGIN_SCREEN;
  static const REGISTER_SCREEM = _Paths.REGISTER_SCREEM;
}

abstract class _Paths {
  _Paths._();
  static const LOGIN_SCREEN = '/login-screen';
  static const REGISTER_SCREEM = '/register-screem';
}
