import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class LoginScreenController extends GetxController {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  final isPasswordVisible = false.obs;
  final rememberMe = true.obs;

  // Reactive theme flag. We read this for our own UI colors AND call
  // Get.changeThemeMode so the rest of the app (ThemeData.light/dark)
  // updates too. Using Obx around this means the toggle reacts the
  // instant it's tapped — no reload needed.
  //
  // IMPORTANT: GetStorage().read(...) returns `dynamic`. Extension
  // getters like `.obs` don't resolve on a dynamic-typed expression,
  // so we must explicitly type the read as bool? first.
  late final RxBool isDarkMode =
      (GetStorage().read<bool>('isDarkMode') ?? true).obs;

  void toggleTheme() {
    isDarkMode.value = !isDarkMode.value;
    GetStorage().write('isDarkMode', isDarkMode.value);
    Get.changeThemeMode(isDarkMode.value ? ThemeMode.dark : ThemeMode.light);
  }

  void togglePassword() {
    isPasswordVisible.value = !isPasswordVisible.value;
  }

  void toggleRemember(bool? value) {
    rememberMe.value = value ?? false;
  }

  Future<void> login() async {
    Get.snackbar(
      "Login",
      "Login button clicked",
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  void continueWithGoogle() {
    // TODO: wire up real Google sign-in (e.g. google_sign_in package
    // or Firebase Auth GoogleAuthProvider) here.
    Get.snackbar(
      "Google",
      "Continue with Google tapped",
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  void continueWithTelegram() {
    // TODO: wire up Telegram Login Widget here. Telegram's web login
    // flow normally embeds https://oauth.telegram.org/auth?bot_id=...
    // (or the widget script from telegram.org/js/telegram-widget.js)
    // inside a webview/iframe — this needs your bot's id + domain
    // registered with @BotFather first.
    Get.snackbar(
      "Telegram",
      "Continue with Telegram tapped",
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    super.onClose();
  }
}