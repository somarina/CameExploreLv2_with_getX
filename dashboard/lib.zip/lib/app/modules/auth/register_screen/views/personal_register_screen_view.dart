import 'package:dashboard/app/modules/auth/register_screen/controllers/register_screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/state_manager.dart';

class PersonalRegisterScreenView extends GetView<RegisterScreenController> {
  const PersonalRegisterScreenView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}