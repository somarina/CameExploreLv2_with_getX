Map<String, String> kmKH = {
  'welcome_back': 'ចូលប្រើប្រាស់',
  'sign_in_to_continue': 'តើអ្នកមិនធ្លាប់មានគណនីមែនទេ?',
  'email': 'អ៊ីមែល',
  'password': 'លេខសម្ងាត់',
  'remember_me': 'ចងចាំគណនីរបស់ខ្ញុំ',
  'forgot_password': 'ភ្លេចពាក្យសម្ងាត់?',
  'sign_in': 'ចូលប្រើប្រាស់',
  'continue_with': 'ចូលប្រើប្រាស់ជាមួយ',
  'continue_with_google': 'ចូលប្រើប្រាស់ជាមួយ Google',
  'continue_with_telegram': 'ចូលប្រើប្រាស់ជាមួយ Telegram',
  'register': 'បង្កើតគណនី',
};