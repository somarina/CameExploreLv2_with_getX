Map<String, String> enUS = {
  'welcome_back': 'Login',
  'sign_in_to_continue': 'Do you have an account?',
  'email': 'Email',
  'password': 'Password',
  'remember_me': 'Remember me',
  'forgot_password': 'Forgot Password?',
  'sign_in': 'Sign In',
  'continue_with': 'Or continue with',
  'continue_with_google': 'Continue with Google',
  'continue_with_telegram': 'Continue with Telegram',
  'register': 'Register',
};