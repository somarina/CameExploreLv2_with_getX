import 'package:flutter/material.dart';
import 'package:get/get.dart';

part 'user_profile_screen_binding.dart';
part 'user_profile_screen_controller.dart';

class UserProfileScreenView extends GetView<UserProfileScreenViewController> {
  const UserProfileScreenView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          _header(),

        ],
      ),
    );
  }
  Widget _header() {
    return Padding(
      padding:  EdgeInsets.all(20),
      child: Column(
        children: [
           CircleAvatar(
            radius: 45,
            backgroundImage: AssetImage('assets/avatar.png'),
          ),
           SizedBox(height: 10),
          controller.isLogin.value
              ? Column(
                  children: [
                    Text(
                      controller.userName.value,
                      style:  TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      controller.email.value,
                      style:  TextStyle(color: Colors.white70),
                    ),
                  ],
                )
              : Container(
                  padding:
                       EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade100,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child:  Text("Guest User"),
                ),
        ],
      ),
    );
  }
}