from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from fastapi import HTTPException
from app.routes import places, auth, reviews, profile, auth_dashboard
from app.routes import favorites
from app.routes import search
from app.routes import discover
from app.routes import categories
from app.routes import hotels
from app.routes import packages
from app.routes import bookings
from app.routes import listing_reviews
from app.routes import ai_assistant
from app.config.cloudinary_config import *
import cloudinary.uploader

app = FastAPI(
    title="CamExplore API",
    description="Tourism and Cultural Places API for Cambodia",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Test 
@app.on_event("startup")
async def startup_check():
    try:
        from app.db.daatabase import client
        await client.admin.command("ping")
        print("MongoDB Atlas connected successfully!")
    except Exception as e:
        print(f"MongoDB Atlas connection failed: {e}")


# ── Global error handlers───────────────────────────────────
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    detail = exc.detail
    if isinstance(detail, dict) and "result" in detail:
        return JSONResponse(status_code=exc.status_code, content=detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={"result": False, "message": str(detail), "data": {}},
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    errors = exc.errors()
    first = errors[0] if errors else {}
    field = " -> ".join(str(l) for l in first.get("loc", []) if l != "body")
    msg = first.get("msg", "Validation error")
    message = f"{field}: {msg}" if field else msg
    return JSONResponse(
        status_code=422,
        content={"result": False, "message": message, "data": {}},
    )


# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(auth.router)

# Dashboard Authentication
app.include_router(auth_dashboard.router)

# database routers
app.include_router(reviews.router)
app.include_router(categories.router)
app.include_router(places.router)
app.include_router(hotels.router)
app.include_router(packages.router)
app.include_router(bookings.router)
app.include_router(listing_reviews.router)
app.include_router(profile.router)
app.include_router(favorites.router)
app.include_router(search.router)
app.include_router(discover.router)
app.include_router(ai_assistant.router)

@app.get("/")
async def root():
    return {"result": True, "message": "CamExplore Backend is running", "data": {}}