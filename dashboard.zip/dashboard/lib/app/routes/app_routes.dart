// ignore_for_file: constant_identifier_names

part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const LOGIN_SCREEN = _Paths.LOGIN_SCREEN;
  static const REGISTER_SCREEM = _Paths.REGISTER_SCREEM;
  static const PERSONAL_REGISTER_SCREEN = _Paths.PERSONAL_REGISTER_SCREEN;
  static const COMPANY_REGISTER_SCREEN = _Paths.COMPANY_REGISTER_SCREEN;
  static const ADMIN_SCREEN = _Paths.ADMIN_SCREEN;
  static const FORGET_PASSWORD = _Paths.FORGET_PASSWORD;
  static const OTP_VERIFICATION = _Paths.OTP_VERIFICATION;
  static const RESET_PASSWORD = _Paths.RESET_PASSWORD;
  static const COMPANY_SCREEN = _Paths.COMPANY_SCREEN;
}

abstract class _Paths {
  _Paths._();
  static const LOGIN_SCREEN = '/login-screen';
  static const REGISTER_SCREEM = '/register-screem';
  static const PERSONAL_REGISTER_SCREEN = '/personal-register-screen';
  static const COMPANY_REGISTER_SCREEN = '/company-register-screen';
  static const ADMIN_SCREEN = '/admin-screen';
  static const FORGET_PASSWORD = '/forget-password';
  static const OTP_VERIFICATION = '/otp-verification';
  static const RESET_PASSWORD = '/reset-password';
  static const COMPANY_SCREEN = '/company-screen';
}
